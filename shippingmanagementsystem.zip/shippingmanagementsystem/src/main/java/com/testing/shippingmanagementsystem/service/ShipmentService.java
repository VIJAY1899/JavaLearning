package com.testing.shippingmanagementsystem.service;

import java.util.List;

import com.testing.shippingmanagementsystem.entity.Shipment;
import com.testing.shippingmanagementsystem.repo.ShipmentRepository;

public class ShipmentService {

	private ShipmentRepository shipmentRepository = ShipmentRepository.getInstance();
	private static ShipmentService shipmentService;

	private ShipmentService() {
	}

	public static ShipmentService getInstance() {
		if (shipmentService == null) {
			shipmentService = new ShipmentService();
		}
		return shipmentService;
	}

	public Shipment add(Shipment order) {
		return shipmentRepository.add(order);
	}

	public Shipment get(int id) {
		return shipmentRepository.getId(id);
	}

	public void delete(int id) {
		shipmentRepository.delete(id);
	}

	public void update(int id) {
		shipmentRepository.update(id);
	}

	public List<Shipment> getByShipments() {
		return shipmentRepository.getByShipments();
	}

}
