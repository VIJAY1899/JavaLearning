package com.testing.shippingmanagementsystem.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.testing.shippingmanagementsystem.entity.Order;

public class OrderRepository {

	private List<Order> orders = new ArrayList<>();

	private static OrderRepository orderRepository;

	private OrderRepository() {
	}

	public static OrderRepository getInstance() {
		if (orderRepository == null) {
			orderRepository = new OrderRepository();
		}
		return orderRepository;
	}

	public Order add(Order order) {
		boolean result = orders.add(order);
		if (result) {
			orders.add(order);
		}
		return null;
	}

	public Order getId(int id) {
		Optional<Order> product = orders.stream().filter(p -> p.getId() == id).findFirst();
		return product.orElse(null);
	}

	public void delete(int id) {
		orders.removeIf(e -> e.getId() == id);
	}

	public void update(int id) {
		orders.stream().filter(p -> p.getId() == id).forEach(p -> p.setCustomer("asd"));
	}

	public List<Order> getByOrders() {
		if (orders.isEmpty()) {
			return new ArrayList<>();
		} else {
			return orders;
		}
	}

}
