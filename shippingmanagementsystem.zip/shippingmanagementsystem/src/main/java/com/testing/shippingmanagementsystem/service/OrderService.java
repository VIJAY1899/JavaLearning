package com.testing.shippingmanagementsystem.service;

import java.util.List;

import com.testing.shippingmanagementsystem.entity.Order;
import com.testing.shippingmanagementsystem.repo.OrderRepository;

public class OrderService {

	private OrderRepository orderRepository = OrderRepository.getInstance();
	private static OrderService orderService;

	private OrderService() {
	}

	public static OrderService getInstance() {
		if (orderService == null) {
			orderService = new OrderService();
		}
		return orderService;
	}

	public Order add(Order order) {
		return orderRepository.add(order);
	}

	public Order get(int id) {
		return orderRepository.getId(id);
	}

	public void delete(int id) {
		orderRepository.delete(id);
	}

	public void update(int id) {
		orderRepository.update(id);
	}

	public List<Order> getByOrders() {
		return orderRepository.getByOrders();
	}
}
