package com.testing.shippingmanagementsystem.entity;


public class Shipment {

	private int id;
	private Order order;
	private String trackingNumber;
	private String assignedDriver;

	public Shipment(int id, Order order, String trackingNumber, String assignedDriver) {
		super();
		this.id = id;
		this.order = order;
		this.trackingNumber = trackingNumber;
		this.assignedDriver = assignedDriver;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public String getTrackingNumber() {
		return trackingNumber;
	}

	public void setTrackingNumber(String trackingNumber) {
		this.trackingNumber = trackingNumber;
	}

	public String getAssignedDriver() {
		return assignedDriver;
	}

	public void setAssignedDriver(String assignedDriver) {
		this.assignedDriver = assignedDriver;
	}

	@Override
	public String toString() {
		return "Shipment [id=" + id + ", order=" + order + ", trackingNumber=" + trackingNumber + ", assignedDriver="
				+ assignedDriver + "]";
	}

}
