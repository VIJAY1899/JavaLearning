package com.hlag.logisticsystem;


public class FragileCargo extends Cargo {

	@Override
	public int calculateAmount(int value1) {
		super.calculateAmount(value1);
		return value1 + 100;
	}

	@Override
	public int calculateAmount(int value1, int value2) {
		super.calculateAmount(value1, value2);
		return value1 + 200 + value2;
	}

}
