package com.hlag.logisticsystem.repo;


public class HeavyCargo extends PerishableCargo {

	public HeavyCargo(int value1, int value2) {
		super(value1, value2);
	}

	public void test3(int value1, int value2) {
		int total = value1 + value2;
		System.out.println(total);
	}

}
