package com.hlag.logisticsystem;


public class Test {

	public static void manin(String[] arg) {

		Flyable f = new IronMan();
		f.fly();
		Flyable.staticMethod();

	}
}
