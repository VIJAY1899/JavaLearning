package com.hlag.logisticsystem;


public class Base {

	int value1;
	int value2;

	// public Base() {
	//
	// }

	// protected Base(int value1, int value2) {
	// System.out.println(value1 + value2);
	// }

	public void test() {

	}




}
