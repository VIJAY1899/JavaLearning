package com.hlag.logisticsystem;
public class CargoItem {

	private double weight;
	private String dimensions;
	private String type;

	public CargoItem(double weight, String dimensions, String type) {
		this.weight = weight;
		this.dimensions = dimensions;
		this.type = type;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public String getDimensions() {
		return dimensions;
	}

	public void setDimensions(String dimensions) {
		this.dimensions = dimensions;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double calculateShippingCost() {
		double baseCost = 10;
		if (weight <= 1) {
			return baseCost;
		} else {
			return baseCost + (weight - 1) * 5;
		}
	}



	public static void main(String[] args) {
		new CargoItem(2, "Cargo", "Standard");

	}
}