package com.hlag.logisticsystem.service;

import com.hlag.logisticsystem.repo.Cargo;
import com.hlag.logisticsystem.repo.HeavyCargo;
import com.hlag.logisticsystem.repo.PerishableCargo;

public class Test {

	public static void manin(String[] args) {

		Cargo cargo = new Cargo(10, 10);
		cargo.test(10, 3);

		PerishableCargo perishableCargo = new PerishableCargo(14, 10);
		perishableCargo.test1(15, 1);

		HeavyCargo heavyCargo = new HeavyCargo(19, 10);
		heavyCargo.test3(13, 3);
	}
}
