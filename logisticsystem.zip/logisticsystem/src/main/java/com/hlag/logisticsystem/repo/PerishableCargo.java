package com.hlag.logisticsystem.repo;


public class PerishableCargo extends Cargo {

	public PerishableCargo(int value1, int value2) {
		super(value1, value2);
	}


	public void test1(int value1, int value2) {
		int total = value1 + value2;
		System.out.println(total);
	}
}
