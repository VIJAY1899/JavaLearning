package com.hlag.logisticsystem;

public class IronMan implements Flyable {


	@Override
	public void fly() {
		// TODO Auto-generated method stub

	}

	public static void staticMethod() {

	}

}
