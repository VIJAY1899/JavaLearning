package com.hlag.logisticsystem;


public class CargoDeom {

	public static void manin(String[] args) {

		Cargo cargo = new Cargo();
		cargo.calculateAmount(100);
		cargo.calculateAmount(100, 200);

		Cargo fragileCargo = new FragileCargo();
		fragileCargo.calculateAmount(300);
		fragileCargo.calculateAmount(200, 400);
	}

}
