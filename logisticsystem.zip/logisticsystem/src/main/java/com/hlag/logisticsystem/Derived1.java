package com.hlag.logisticsystem;

public class Derived1 extends Base {

	// public Derived1() {
	// super(10, 20);
	// }

	
	@Override
	public void test() {

	}

}
