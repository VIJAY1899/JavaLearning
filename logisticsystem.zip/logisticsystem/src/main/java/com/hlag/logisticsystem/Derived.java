package com.hlag.logisticsystem;

public class Derived extends Derived1 {

	// protected Derived() {
	//
	// }

	// public Derived() {
	// super(10, 20);
	// }



	// public Derived(int value1, int value2) {
	// super(10, 20);
	// this.value1 = value1;
	// this.value2 = value2;
	// }
	//
	// public Derived() {
	// }

}
