package com.hlag.logisticsystem;


public class Cargo {

	public int calculateAmount(int value1) {
		return value1 + 100;
	}

	public int calculateAmount(int value1, int value2) {
		return value1 + 100 + value2;
	}

}
