package com.hlag.logisticsystem.dto;

import com.hlag.logisticsystem.Derived1;

public class Test {

	public static void manin(String[] arg) {

		Derived1 derived1 = new Derived1();

	}

}
