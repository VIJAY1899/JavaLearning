package com.hlag.logisticsystem.dto;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

public class Package {

	private final String trackingId;
	private double weight;
	private String destination;
	private String status;
	private List<String> milestone;

	// public Package() {// Default constructor
	// this.trackingId = "";
	// }
	//
	// public Package(String trackingID, String destination, double weight) {
	// super();
	// this.trackingId = trackingID;//
	// this.destination = destination;
	// this.status = "In Transit"; // Initial status
	// this.milestone = new ArrayList<>();
	// setWeight(weight);
	// }



	public String getTrackingId() {
		return trackingId;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		if (weight <= 0) {
			throw new IllegalArgumentException("Weight must be positive");
		}
		this.weight = weight;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getStatus() {
		return status;
	}


	public List<String> getMilestone() {
		return Collections.unmodifiableList(milestone);
	}


	public void markAsDelivered(String status) {
		if (this.status.equals(status)) {
			throw new IllegalArgumentException("package is in transtion");
		}
		this.status = "delivered";
		this.milestone.add("delivered on" + LocalDate.now());
	}

	private Package() {
		this.trackingId = "";
	}

	private static Package pack;

	public static Package getInstance() {
		if (pack == null) {// no needed
			pack = new Package();
		}
		return pack;
	}

}
