package com.hlag.logisticInheritance;


public class MainClass {

	public static void main(String[] args) {
		Orange orange = new Orange(20, 30);
		orange.get(10, 20);
		orange.a = 10;
	}

}
