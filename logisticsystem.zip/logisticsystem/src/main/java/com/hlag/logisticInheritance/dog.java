package com.hlag.logisticInheritance;


public class dog {

	public void sound() {
		System.out.println("Dog");
	}

}
