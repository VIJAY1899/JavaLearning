package com.hlag.logisticInheritance;


public class Cat extends dog {

	@Override
	public void sound() {
		System.out.println("Cat");
	}

}
