package com.hlag.logisticInheritance;


public class Animal {

	public static void main(String[] args) {
		dog ss = new Cat();
		ss.sound();
	}

}
