package com.hlag.logisticInheritance;


public class Orange extends Apple {

	public Orange(int a, int b) {
		super(a, b);
	}

	@Override
	public void get(int a, int b) {
		super.get(a, b);
		double valu = a - b;
		System.out.println(valu);
	}

}
