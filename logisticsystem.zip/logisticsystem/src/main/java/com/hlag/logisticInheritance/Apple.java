package com.hlag.logisticInheritance;


public class Apple {

	int a;
	int b;

	public Apple(int a, int b) {
		this.a = a;
		this.b = b;
	}

	public void get(int a, int b) {
		double valu = a + b;
		System.out.println(valu);
	}

}
