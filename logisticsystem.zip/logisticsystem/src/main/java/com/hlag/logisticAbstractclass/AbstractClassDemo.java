package com.hlag.logisticAbstractclass;


public class AbstractClassDemo {

	public static void main(String[] args) {
		CargoItem cargoItem1 = new CargoItem1();
		cargoItem1.sound();

		CargoItem1 cargoItem12 = (CargoItem1) cargoItem1;
		cargoItem12.sleep();
	}

}
