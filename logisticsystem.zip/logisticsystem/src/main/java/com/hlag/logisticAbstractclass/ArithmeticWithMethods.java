package com.hlag.logisticAbstractclass;


public class ArithmeticWithMethods {
	
	int a;
	int b;
	int c;

	public ArithmeticWithMethods(int a, int b, int c) {
		int total = a + b;
		System.out.println("total>>>>>>>>>>>>>>>" + total);
	}

//Method to calculate the final price after discount
  public static double calculateFinalPrice(int a, double pricePerItem, double discountRate) {
      // Step 1: Calculate the total cost
      double totalCost = a * pricePerItem;

      // Step 2: Apply discount
      double discountAmount = totalCost * discountRate;
      double finalPrice = totalCost - discountAmount;

      // Step 3: Return the final price
      return finalPrice;
  }

  public static void main(String[] args) {
      // Declare input values
      int a = 10;                // Number of items
      double pricePerItem = 15.99;  // Price per item
      double discountRate = 0.10;   // 10% discount

      // Call the method and store the result
			double finalPrice1 = calculateFinalPrice(a, pricePerItem, discountRate);
			ArithmeticWithMethods arithmeticWithMethods = new ArithmeticWithMethods(10, 20, 30);
      // Print out the results
      System.out.println("Number of items: " + a);
      System.out.println("Price per item: $" + pricePerItem);
      System.out.println("Discount rate: " + (discountRate * 100) + "%");
			System.out.println("Final price after discount: $" + finalPrice1);
  }


}
