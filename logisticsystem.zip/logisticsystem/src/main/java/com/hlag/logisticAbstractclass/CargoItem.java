package com.hlag.logisticAbstractclass;


public abstract class CargoItem {

	public abstract void sound();

	public void sleep() {
		System.out.println("This animal is sleeping.");
	}

}
