package com.hlag.logisticAbstractclass;


public interface Trackable {

	void trackCargo();
}
