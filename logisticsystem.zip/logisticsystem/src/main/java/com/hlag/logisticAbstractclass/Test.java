package com.hlag.logisticAbstractclass;


public class Test {

	public static void main(String[] args) {
		Cargo cargo = new Cargo();
		cargo.trackCargo();
	}

}
