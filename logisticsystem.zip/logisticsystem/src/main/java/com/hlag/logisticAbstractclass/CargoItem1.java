package com.hlag.logisticAbstractclass;


public class CargoItem1 extends CargoItem {

	@Override
	public void sound() {
		System.out.println("Meow! Meow!");
	}

	public void wagTail() {
		System.out.println("The dog is wagging its tail.");
	}

}
