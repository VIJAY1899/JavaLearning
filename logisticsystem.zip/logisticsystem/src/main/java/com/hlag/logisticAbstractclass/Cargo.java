package com.hlag.logisticAbstractclass;


public class Cargo implements Trackable {

	@Override
	public void trackCargo() {

	}

}
