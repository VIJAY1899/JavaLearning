package com.testing.repo;

import java.util.List;

import com.testing.exception.InvalidNameException;
import com.testing.product.Product;

public interface ProductRepository {

	void add(Product product);

	Product get(String productID);

	void update(String productID, Product product) throws InvalidNameException;

	void delete(String productID);

	public List<Product> getByProducts();
}
