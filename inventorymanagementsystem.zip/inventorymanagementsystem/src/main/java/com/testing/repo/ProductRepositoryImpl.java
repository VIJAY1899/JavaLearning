package com.testing.repo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.testing.exception.InvalidNameException;
import com.testing.product.Product;

public class ProductRepositoryImpl implements ProductRepository {

	private List<Product> products = new ArrayList<>();

	private static ProductRepositoryImpl productRepositoryImpl;

	private ProductRepositoryImpl() {
	}

	public static ProductRepositoryImpl getInstance() {
		if (productRepositoryImpl == null) {
			productRepositoryImpl = new ProductRepositoryImpl();
		}
		return productRepositoryImpl;
	}

	@Override
	public void add(Product product) {
		products.add(product);

	}

	@Override
	public Product get(String productID) {
		Optional<Product> product = products.stream()
				.filter(p -> p.getProductID().toString().equals(productID))
				.findFirst();
		return product.orElse(null);
	}

	@Override
	public void update(String productID, Product updatedProduct) throws InvalidNameException {
		Product product = get(productID);
		if (product != null) {
			product.update(
					updatedProduct.getName(),
					updatedProduct.getDescription(),
					updatedProduct.getPrice(),
					updatedProduct.getQuantity());
		}
	}

	@Override
	public void delete(String productID) {
		Product product = get(productID);
		if (product != null) {
			products.remove(product);
		}
	}

	@Override
	public List<Product> getByProducts() {
		if (products.isEmpty()) {
			return new ArrayList<>();
		} else {
			return products;
		}
	}

}
