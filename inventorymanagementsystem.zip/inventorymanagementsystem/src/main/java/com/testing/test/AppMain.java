package com.testing.test;

import java.util.List;

import com.testing.exception.InvalidNameException;
import com.testing.product.Product;
import com.testing.service.CrudOperations;
import com.testing.service.InventoryService;

public class AppMain {

	public static void main(String[] args) throws InvalidNameException {
		CrudOperations crudOperations = InventoryService.getInstance();
		Product product = new Product("ASD", "ASS", 4, 1);

		curdOperationCase("Add", product, crudOperations);
		// curdOperationCase("ProductId", product, crudOperations);
		// curdOperationCase("GetListProducts", product, crudOperations);
		// curdOperationCase("Update", product, crudOperations);
		curdOperationCase("Delete", product, crudOperations);
	}

	public static void curdOperationCase(String ss, Product u, CrudOperations inventoryService) throws InvalidNameException {

		switch (ss) {
			case "Add":
				inventoryService.add(u);
				break;
			case "GetListProducts":
				List<Product> productbyUser = inventoryService.getByProducts();
				if (productbyUser != null) {
					System.out.println("productbyUser :: " + productbyUser);
				}
				break;
			case "ProductId":
				Product productbyId = inventoryService.get(u.getProductID().toString());
				if (productbyId != null) {
					System.out.println("productbyId :: " + productbyId);
				}
				break;
			case "Update":
				inventoryService.update(u.getProductID().toString(), u);
				System.out.println("updated successfully ");
				break;
			case "Delete":
				inventoryService.delete(u.getProductID().toString());
				System.out.println("deleted successfully ");
				break;
			default:
				System.out.println("please try again.");
		}
	}
	}

