package com.testing.product;

import java.util.UUID;

import com.testing.exception.InvalidNameException;

public class Product extends InvalidNameException {

	private UUID productID;
	private String name;
	private String description;
	private double price;
	private int quantity;

	public Product(String name, String description, double price, int quantity)
			throws InvalidNameException {
		super();
		setProductID();
		this.name = name;
		this.description = description;
		setPrice(price);
		setQuantity(quantity);
	}

	public void update(String name, String description, double price, int quantity) {
		this.name = name;
		this.description = description;
		this.price = price;
		this.quantity = quantity;
	}


	public UUID getProductID() {
		return productID;
	}

	public void setProductID() {
		this.productID = UUID.randomUUID();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) throws InvalidNameException {
		if (price >= 0) {
			this.price = price;
		} else {
			throw new InvalidNameException("Price cannot be negative");
		}
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) throws InvalidNameException {
		if (quantity >= 0) {
			this.quantity = quantity;
		} else {
			throw new InvalidNameException("Quantity cannot be negative");
		}
	}

	@Override
	public String toString() {
		return "Product [productID=" + productID + ", name=" + name + ", description=" + description + ", price=" + price
				+ ", quantity=" + quantity + "]";
	}
}
