package com.testing.service;

import java.util.List;

import com.testing.exception.InvalidNameException;
import com.testing.product.Product;

public interface CrudOperations {

	Product add(Product product);

	Product get(String productID);

	Product update(String productID, Product product) throws InvalidNameException;

	void delete(String productID);

	public List<Product> getByProducts();

}
