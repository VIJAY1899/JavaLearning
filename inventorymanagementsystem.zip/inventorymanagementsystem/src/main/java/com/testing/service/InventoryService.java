package com.testing.service;

import java.util.List;

import com.testing.exception.InvalidNameException;
import com.testing.product.Product;
import com.testing.repo.ProductRepository;
import com.testing.repo.ProductRepositoryImpl;

public class InventoryService implements CrudOperations {

	private ProductRepository productRepository = ProductRepositoryImpl.getInstance();
	private static InventoryService inventoryService;

	private InventoryService() {
	}

	public static InventoryService getInstance() {
		if (inventoryService == null) {
			inventoryService = new InventoryService();
		}
		return inventoryService;
	}

	@Override
	public Product add(Product product) {
		return productRepository.add(product);
	}

	@Override
	public Product get(String productID) {
		return productRepository.get(productID);
	}

	@Override
	public Product update(String productID, Product product) throws InvalidNameException {
		return productRepository.update(productID, product);
	}

	@Override
	public void delete(String productID) {
		productRepository.delete(productID);
	}

	@Override
	public List<Product> getByProducts() {
		return productRepository.getByProducts();
	}
}
