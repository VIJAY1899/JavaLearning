package com.testing.Threads;

import java.util.stream.IntStream;

public class ThreadDemo {

	public static void main(String[] args) {

		Runnable runnable = () -> {

			IntStream.rangeClosed(1, 10).forEach(System.out::println);
		};

		Thread thread = new Thread(runnable);
		thread.start();

		Thread.getAllStackTraces().forEach((k, v) -> {
			System.out.println(k);
		});
	}

}
