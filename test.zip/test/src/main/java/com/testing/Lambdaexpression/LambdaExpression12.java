package com.testing.Lambdaexpression;


public class LambdaExpression12 {

	@FunctionalInterface
	interface CargoProcessor {

		void process(String cargo);
	}



		public static void main(String[] args) {
			CargoProcessor processor = cargo -> System.out.println("Processing cargo: " + cargo);
			processor.process("Electronics");
		}


}
