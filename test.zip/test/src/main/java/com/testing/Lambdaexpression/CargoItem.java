package com.testing.Lambdaexpression;


public class CargoItem {

	private String name;
	private double weight;
	private String category;

	public CargoItem(String name, double weight, String category) {
		this.name = name;
		this.weight = weight;
		this.category = category;
	}

	// Getters
	public String getName() {
		return name;
	}

	public double getWeight() {
		return weight;
	}

	public String getCategory() {
		return category;
	}

	@Override
	public String toString() {
		return "CargoItem{name='" + name + "', weight=" + weight + ", category='" + category + "'}";
	}

}
