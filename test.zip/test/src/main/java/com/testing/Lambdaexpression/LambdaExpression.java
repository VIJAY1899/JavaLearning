package com.testing.Lambdaexpression;


public class LambdaExpression {

	public static void main(String[] args) {
		// Function interface
		// I5 i5 = new I1Impl();
		// i5.test();
		// i5.test2();

		// LamdaExperssion
		// I5 i7 = () -> true;
		// System.out.println(i7.test());
		// i7.test2();

		I5 i7 = () -> {
			System.out.println("hellow from lambda");
		};
		i7.test();
		i7.test2();
		// // Anonymys
		// I5 i6 = new I5() {
		//
		// @Override
		// public boolean test() {
		// System.out.println("hello from test");
		// return true;
		// }
		//
		// @Override
		// public void test2() {
		// System.out.println("helo from test2");
		// }
		// };
		// i6.test();
		// i6.test2();
	}
}

	@FunctionalInterface
interface I5 {

	public void test();
		public default void test2() {
			System.out.println("helo from test2");
		}
	}

	class I1Impl implements I5 {

		@Override
		public void test() {
			System.out.println("hello from test");
		}

		@Override
		public void test2() {
			System.out.println("test2 is overridden");
		}
}
