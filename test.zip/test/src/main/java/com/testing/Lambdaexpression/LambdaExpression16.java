package com.testing.Lambdaexpression;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class LambdaExpression16 {

	public static List<CargoItem> getCargoItems() {
		return Arrays.asList(
				new CargoItem("Laptop", 2.5, "Electronics"),
				new CargoItem("Phone", 0.5, "Electronics"),
				new CargoItem("Washing Machine", 80, "Appliances"),
				new CargoItem("Table", 30, "Furniture"),
				new CargoItem("Refrigerator", 60, "Appliances"),
				new CargoItem("Chair", 10, "Furniture"),
				new CargoItem("Microwave", 15, "Appliances"));
	}

	public static List<CargoItem> filterByWeight(List<CargoItem> cargoItems, double minWeight) {
		return cargoItems.stream().filter(e -> e.getWeight() >= minWeight).collect(Collectors.toList());
	}

	public static List<CargoItem> sortByWeight(List<CargoItem> cargoItems) {
		return cargoItems.stream()
				.sorted(Comparator.comparingDouble(CargoItem::getWeight).reversed())// reversed high weight amout
				.collect(Collectors.toList());
	}

	public static long countByCategory(List<CargoItem> cargoItems, String category) {
		return cargoItems.stream().filter(item -> item.getCategory().equalsIgnoreCase(category)).count();
	}

	public static List<CargoItem> sortByName(List<CargoItem> cargoItems) {
		return cargoItems.stream().sorted(Comparator.comparing(CargoItem::getName)).collect(Collectors.toList());
	}

	public static void main(String[] args) {
		List<CargoItem> cargosss = getCargoItems();

		List<CargoItem> liss = filterByWeight(cargosss, 20);
		liss.forEach(System.out::println);

		List<CargoItem> liss2 = sortByWeight(cargosss);
		liss2.forEach(System.out::println);

		Long valu = countByCategory(cargosss, "Electronics");
		System.out.println("Electronics count: " + valu);

		List<CargoItem> liss3 = sortByName(cargosss);
		liss3.forEach(System.out::println);
	}

}
