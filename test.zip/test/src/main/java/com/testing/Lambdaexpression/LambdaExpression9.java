package com.testing.Lambdaexpression;


public class LambdaExpression9 {

	public static void main(String[] args) {
		StringManipulator stringManipulator = (String ar) -> ar.toUpperCase();
		String sss = stringManipulator.getValue("Vijay");
		System.out.println(sss);

		StringManipulator stringManipulatorReverse = (String ar) -> new StringBuilder(sss).reverse().toString();
		String sss1 = stringManipulatorReverse.getValue("Vijay");
		System.out.println(sss1);

	}

	@FunctionalInterface
	interface StringManipulator {

		public String getValue(String ar);

	}

}
