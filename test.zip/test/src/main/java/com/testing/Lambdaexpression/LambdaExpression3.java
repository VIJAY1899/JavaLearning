package com.testing.Lambdaexpression;


public class LambdaExpression3 {

	public static void main(String[] args) {
		Greeter greeter = (String name) -> name;
		System.out.println(greeter.greet(" Hello, Alice!"));

		getValues(greeter);
	}

	public static void getValues(Greeter greeter) {
		System.out.println(greeter.greet("Hello "));
	}

	@FunctionalInterface
	interface Greeter {
		public String greet(String name);
	}

}
