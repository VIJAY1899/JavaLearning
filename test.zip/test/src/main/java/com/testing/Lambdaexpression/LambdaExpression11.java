package com.testing.Lambdaexpression;

import java.util.Arrays;
import java.util.List;

public class LambdaExpression11 {

	public static void main(String[] args) {
		List<String> cargoList = Arrays.asList("Electronics", "Furniture", "Clothing");

		// Using lambda expression to print each item
		cargoList.forEach(item -> System.out.println(item));
	}

}
