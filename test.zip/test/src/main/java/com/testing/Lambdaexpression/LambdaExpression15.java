package com.testing.Lambdaexpression;


public class LambdaExpression15 {

	public static void main(String[] args) {
		CargoProcessor cargoProcessor=(String value, double weight)->{
			double total=weight+10;
			String values = value.toUpperCase();
			return "total :" + total + "  " + "Name :" + values;
		};
		
		String ss = cargoProcessor.processorCargo("vijay", 1);
		System.out.println(ss);
	}
}
	interface CargoProcessor {

		public String processorCargo(String value, double weight);
	}


