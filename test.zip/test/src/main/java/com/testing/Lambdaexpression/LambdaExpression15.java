package com.testing.Lambdaexpression;


public class LambdaExpression15 {

	public static void main(String[] args) {

	}

	interface CargoProcessor {

		public String processorCargo(String value, double weight);
	}

}
