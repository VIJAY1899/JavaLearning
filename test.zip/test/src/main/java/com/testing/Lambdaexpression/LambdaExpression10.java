package com.testing.Lambdaexpression;


public class LambdaExpression10 {

	public static void main(String[] args) {

		Processor processorAdd = (int number) -> number + 10;
		int value = processorAdd.processer(20);
		System.out.println(value);

		Processor processorMultiple = (int number) -> number * 2;
		int value1 = processorMultiple.processer(5);
		System.out.println(value1);

		Processor processordivided = (int number) -> number / 5;
		int value3 = processordivided.processer(35);
		System.out.println(value3);
	}

	interface Processor {

		public int processer(int number);

	}

}
