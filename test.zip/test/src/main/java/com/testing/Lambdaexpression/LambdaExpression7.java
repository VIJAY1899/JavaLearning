package com.testing.Lambdaexpression;

public class LambdaExpression7 {

	public static void main(String[] args) {
		Comparator comparator = (String a, String b) -> Integer.compare(a.length(), b.length());
		int a = comparator.getValue("appleas", "banana");

		if (a < 0) {
			System.out.println("apple low");
		} else if (a > 0) {
			System.out.println("banana high");
		} else {
			System.out.println("Apple and banana equal");
		}
	}

	@FunctionalInterface
	interface Comparator {

		public int getValue(String a, String b);
	}

}
