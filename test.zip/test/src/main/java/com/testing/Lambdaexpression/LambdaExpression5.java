package com.testing.Lambdaexpression;

import java.util.HashMap;
import java.util.Map;

public class LambdaExpression5 {

	public static void main(String[] args) {
		Demo demo = (int a) -> a % 2 == 0;
		System.out.println(demo.get(11));

		getValue();

	}

	public static void getValue() {
		Map<String, Integer> map = new HashMap<>();
		map.put("A", 10);
		map.put("B", 20);
		map.put("C", 30);
		map.put("D", 40);
		map.put("E", 50);
		// System.out.println("map.entrySet()" + map.entrySet().size());
		// for (Map.Entry<String, Integer> entry : map.entrySet()) {
		// System.out.println("Key :" + entry.getKey() + " value :" + entry.getValue());
		//
		// }

		// map.forEach((k, v) -> {
		// System.out.println(k + " Key and Value " + v);
		// });

		map.forEach((k, v) -> System.out.println(k + "key and value" + v));
	}

	interface Demo {

		public boolean get(int a);
	}

}
