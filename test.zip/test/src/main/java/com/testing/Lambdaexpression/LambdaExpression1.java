package com.testing.Lambdaexpression;


public class LambdaExpression1 {

	public static void main(String[] args) {
		// Function interface
		// I5 i5 = new I1Impl();
		// i5.test();
		// i5.test2();

		// // LamdaExperssion
		// I5 i7 = () -> true;
		// System.out.println(i7.test());
		// i7.test2();

		// I5 i7 = () -> {
		// System.out.println("hellow from lambda");
		// };
		// i7.test();
		// i7.test2();
		// // Anonymys
		// I5 i6 = new I5() {
		//
		// @Override
		// public boolean test() {
		// System.out.println("hello from test");
		// return true;
		// }
		//
		// @Override
		// public void test2() {
		// System.out.println("helo from test2");
		// }
		// };
		// i6.test();
		// i6.test2();

		I8 i8 = (int a, int b) -> a + b;
		int res = i8.test(10, 20);
		System.out.println(res);

		// demo(i8);// static method

		demo((a, b) -> a + b + 100);// directly pass argument
		// I8 i8 = new I8() {
		//
		// @Override
		// public void test(int a, int b) {
		// System.out.println(a + b);
		//
		// }
		// };
		// i8.test(10, 20);
	}

	public static void demo(I8 i8) {
		System.out.println(i8.test(100, 100));

	}

}


	@FunctionalInterface
	interface I8 {

		public int test(int a, int b);

	}


