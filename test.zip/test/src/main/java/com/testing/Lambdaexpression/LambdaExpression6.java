package com.testing.Lambdaexpression;

import java.util.function.Function;

public class LambdaExpression6 {

	public static void main(String[] args) {
		// Demo demo = (int a, int b) -> a % 2;
		// System.out.println(demo.get(11, 13));
		//
		getValue();

	}

	public static void getValue() {
		Function<String, String> function = x -> x.toUpperCase();
		String a = function.apply("avdfc");
		System.out.println(a);

		// using andThen
		// Function<String, Integer> function = x -> x.length();
		// Function<Integer, Integer> function2 = x -> x * 2;
		// int result = function.andThen(function2).apply("avdfc");
		// System.out.println(result);
	}

	// interface Demo {
	//
	// public int get(int a, int b);
	// }

}
