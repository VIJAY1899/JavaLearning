package com.testing.Lambdaexpression;


public class LambdaExpression8 {

	public static void main(String[] args) {
		MathOperation mathOperation = (int a, int b) -> a + b;
		System.out.println(mathOperation.operator(10, 20));

		MathOperation mathOperationMultiple = (int a, int b) -> a * b;
		System.out.println(mathOperationMultiple.operator(10, 20));

		MathOperation mathOperationDivide = (int a, int b) -> a / b;
		System.out.println(mathOperationDivide.operator(10, 2));
	}

	@FunctionalInterface
	interface MathOperation {

		public int operator(int a, int b);
	}

}
