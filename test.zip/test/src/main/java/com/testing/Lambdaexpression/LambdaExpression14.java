package com.testing.Lambdaexpression;

import java.util.Arrays;
import java.util.List;

public class LambdaExpression14 {

	public static void main(String[] args) {
		List<String> cargoList = Arrays.asList("Electronics", "Furniture", "Clothing");

		// Using method reference to print items
		cargoList.forEach(System.out::println);
	}

}
