package com.testing.Lambdaexpression;


public class LambdaExpression4 {

	public static void main(String[] args) {
		Demo demo = (int a) -> a % 2 == 0;
		boolean value = demo.get(10);
		System.out.println(value);

		// getValue(demo);

	}

	// public static void getValue(Demo demo) {
	// System.out.println(demo.get(10));
	// }

	interface Demo {

		public boolean get(int a);
	}

}
