package com.testing.Lambdaexpression;


public class LambdaExpression2 {

	public static void main(String[] args) {
		I5tt i5tt = (int a) -> a / 7;
		// System.out.println(i5tt.addvalue(21));

		get(i5tt);

		get((a) -> a / 7);
	}


	public static void get(I5tt i5tt) {
		System.out.println(i5tt.addvalue(20));
	}

	interface I5tt {

		public int addvalue(int a);

	}

}
