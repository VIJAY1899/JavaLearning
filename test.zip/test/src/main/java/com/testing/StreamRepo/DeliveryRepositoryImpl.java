package com.testing.StreamRepo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.testing.Stream.Delivery;

public class DeliveryRepositoryImpl implements DeliveryRepository {

	private List<Delivery> deliveries = new ArrayList<>();

	// Save a new delivery
	@Override
	public void save(Delivery delivery) {
		deliveries.add(delivery);
	}

	// Find a delivery by its ID
	@Override
	public Optional<Delivery> findById(String deliveryId) {
		// return deliveries.stream().filter(delivery ->
		// delivery.getDeliveryId().equals(deliveryId)).findFirst().orElse(null);
		return null;
	}

	// Get all deliveries
	@Override
	public List<Delivery> findAll() {
		return new ArrayList<>(deliveries);
	}

	// Update an existing delivery
	@Override
	public void update(Delivery delivery) {
		Optional<Delivery> existingDelivery = findById(delivery.getDeliveryId());
		if (existingDelivery.isPresent()) {
			deliveries.remove(existingDelivery.get());
			deliveries.add(delivery);
		}
	}

	// Delete a delivery by its ID
	@Override
	public void deleteById(String deliveryId) {
		deliveries.removeIf(delivery -> delivery.getDeliveryId().equals(deliveryId));
		// deliveries.stream().filter(e ->
		// e.getDeliveryId().equals(deliveryId)).collect(Collectors.toList()).removeAll(deliveries);
		// deliveries.forEach(e -> System.out.println(e));
	}

	// Get deliveries that are completed
	@Override
	public List<Delivery> findCompletedDeliveries() {
		List<Delivery> completedDeliveries = new ArrayList<>();
		// for (Delivery delivery : deliveries) {
		// if (delivery.isCompleted()) {
		// completedDeliveries.add(delivery);
		// }
		// }
		// completedDeliveries = deliveries.stream().filter(e -> e.isCompleted()).collect(Collectors.toList());
		// completedDeliveries = deliveries.stream().map(e -> e.isCompleted() ? e : null).collect(Collectors.toList());
		completedDeliveries = deliveries.stream().map(e -> e.getRevenue() > 50 ? e : null).collect(Collectors.toList());
		completedDeliveries.forEach(e -> System.out.println(e));
		return completedDeliveries;
	}

	public double calculateTotalRevenue() {
		// double totalRevenue = 0;
		// for (Delivery delivery : deliveries) {
		//// totalRevenue += delivery.getRevenue();
		// totalRevenue =totalRevenue + delivery.getRevenue();
		// }
		// return totalRevenue;
		return deliveries.stream().mapToDouble(e -> e.getRevenue()).sum();
	}

	public double calculateTotalDeliveryTimeInHours() throws IllegalAccessException {
		// return deliveries.stream().mapToDouble(e -> e.getDeliveryTimeInHours()).average().getAsDouble();
		return deliveries.stream()
				.mapToDouble(e -> e.getDeliveryTimeInHours())
				.average()
				.orElseThrow(() -> new IllegalAccessError("data is not provided"));
	}

	public List<Delivery> findtpKPerformingdeliveries(int k) {
		return deliveries.stream()
				.filter(e -> e.isCompleted())
				.sorted((a, b) -> Double.compare(a.getDeliveryTimeInHours(), b.getDeliveryTimeInHours()))
				.limit(k)
				.collect(Collectors.toList());
	}
}
