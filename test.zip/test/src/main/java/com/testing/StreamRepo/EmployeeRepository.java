package com.testing.StreamRepo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.testing.Stream.Delivery;
import com.testing.Stream.Employee;

public class EmployeeRepository {

	private List<Employee> employees = new ArrayList<>();

	public void save(Employee employee) {
		employees.add(employee);
	}

	public List<Employee> findEmployee() {
		return employees.stream().filter(e -> e.getSalary() > 50000).map(e -> e.getName()).collect(Collectors.);
	}

}
