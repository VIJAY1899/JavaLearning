package com.testing.Stream;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class CustomCollectorExample {

	public static void main(String[] args) {
		List<Product> products = Arrays.asList(
				new Product("Laptop", 1200, 12),
				new Product("Mouse", 20, 11),
				new Product("Keyboard", 50, 13),
				new Product("Monitor", 200, 43),
				new Product("Charger", 30, 11));

		// Custom Collector
		Map<String, Double> priceRangeTotals = products.stream().collect(Collectors.groupingBy(p -> {
			if (p.getPrice() < 50) {
				return "<50";
			} else if (p.getPrice() <= 100) {
				return "50-100";
			} else {
				return ">100";
			}

		}, Collector.of(() -> new double[1], (a, p) -> a[0] += p.getPrice(), (a1, a2) -> {
			a1[0] += a2[0];
			return a1;
		}, a -> a[0])));
		priceRangeTotals.forEach((k, v) -> System.out.println(k + "" + v));

		// Map<String, Map<String, Integer>> salesByRegionAndDemographic = products.stream()
		//
		// .collect(
		// Collectors.groupingBy(
		//
		// t -> t.getAge(),
		//
		// Collectors.groupingBy(
		//
		// t -> t.getAge(),
		//
		// Collectors.summingInt(Product::getAge)
		//
		// )
		//
		// ));
	}



}
