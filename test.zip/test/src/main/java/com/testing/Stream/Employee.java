package com.testing.Stream;
// Advanced Stream Operations: map, filter, and reduce
// Scenario: Analyzing employee data for insights
// We have a list of employees with fields like name, salary, department, and age. We want to:
// Filter employees earning more than 50,000.
// Transform the filtered employees into a map of names and salaries.
// Use reduce to calculate the total salary of the filtered employees.
// java
// Copy code

public class Employee {

	String name;
	double salary;
	String department;
	int age;

	public Employee(String name, double salary, String department, int age) {
		super();
		this.name = name;
		this.salary = salary;
		this.department = department;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public double getSalary() {
		return salary;
	}

	public String getDepartment() {
		return department;
	}

	public int getAge() {
		return age;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", salary=" + salary + ", department=" + department + ", age=" + age + "]";
	}

}
