package com.testing.Stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamTest {

	public static void main(String[] args) {
		List<String> words = Arrays.asList("apple", "banana", "cherry", "date", "orange", "jerry");
		List<String> result = new ArrayList<>();

		// for (String word : words) {
		// if (word.length() > 5) {
		// result.add(word.toUpperCase());
		// }
		// System.out.println(result);
		// System.out.println(System.currentTimeMillis());
		//
		// }

		// Stream
		List<String> result1 = words.stream()
				.filter(e -> e.length() > 5)
				.map(e -> e.toUpperCase())
				.collect(Collectors.toList());

		// System.out.println(result1);
		// System.out.println(System.currentTimeMillis());

		result1.stream().forEach(e -> System.out.println(e));
		result1.forEach(e -> System.out.println(e));
	}


}
