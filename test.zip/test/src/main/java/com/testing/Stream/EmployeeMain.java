package com.testing.Stream;

import java.util.Arrays;
import java.util.List;

public class EmployeeMain {

	public static void main(String[] args) {
		List<Employee> employeedetails = Arrays.asList(
				new Employee("Rahul", 50000, "IT", 25),
				// new Employee("Rohit", 60000, "IT", 30),
				new Employee("Raj", 70000, "IT", 35),
				new Employee("Ravi", 80000, "IT", 40),
				new Employee("Rahul", 90000, "IT", 45),
				new Employee("Rohit", 100000, "IT", 50));

		// employeedetails.stream()
		// .filter(e -> e.getSalary() > 50000)
		// .collect(Collectors.toMap(Employee::getName, Employee::getSalary));// key: name and Value:Salary
		
		// employeedetails.stream()
		// .filter(e -> e.getSalary() > 50000)
		// .collect(Collectors.toMap(e -> e.getName(), e -> e.getSalary()))//key and value
		// .forEach((a, b) -> System.out.println(a + " " + b));// key: name and Value:Salary
	 

		double totalsalary = employeedetails.stream()
				.filter(e -> e.getSalary() > 50000)
				.map(Employee::getSalary)
				.reduce(0.0, Double::sum);

		employeedetails.stream().forEach(e -> System.out.println(totalsalary));

	}

}
