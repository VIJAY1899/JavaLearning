package com.testing.repo;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import com.testing.test.exception.InvalidNameException;
import com.testing.user.User;


public class UserRepositoryImpl implements UserRepository {

	private Set<User> users = new HashSet<>();

	private static UserRepositoryImpl userRepositoryImpl;

	private UserRepositoryImpl() {
	}

	public static UserRepositoryImpl getInstance() {
		if (userRepositoryImpl == null) {
			userRepositoryImpl = new UserRepositoryImpl();
		}
		return userRepositoryImpl;
	}

	@Override
	public User addUser(User user) {
		boolean result = users.add(user);
		if (result) {
			return user;
		}
		return null;
	}

	@Override
	public Optional<User> getUserById(String id) {
		UUID uUID = UUID.fromString(id);
		// case1
		// for (User user : users) {
		// if (user.getId().equals(uUID)) {
		// return Optional.of(user);
		// }
		// }
		// return Optional.empty();

		// case2
		return users.stream().filter(e -> e.getId().toString().equals(id)).findFirst();

		// case3
		// AtomicReference<User> atomicReference = new AtomicReference<>();
		// Consumer<User> consumer = e -> {
		// if (e.getId().toString().equals(id)) {
		// atomicReference.set(e);
		// }
		// };
		// users.forEach(consumer);
		// User user3 = atomicReference.get();
		// return Optional.ofNullable(user3);
	}

	@Override
	public Optional<List<User>> getUsers() {
		if (users.isEmpty()) {
			return Optional.empty();
		} else {
			return Optional.of(users);
		}
		// Set
		// if (users.isEmpty()) {
		// return Optional.empty();
		// } else {
		// return Optional.of(new ArrayList<>(users));
		// }
	}

	@Override
	public void deleteUser(String id) {
		UUID uUID = UUID.fromString(id);
		for (User user : users) {
			if (user.getId().equals(uUID)) {
				users.remove(user);
			}
			throw new IllegalArgumentException("User Id not Matched");
		}
		
	}


	@Override
	public User updateUser(String id, User user) throws InvalidNameException {
		UUID uUID = UUID.fromString(id);
		for (User user1 : users) {
			if (user1.getId().equals(uUID)) {
				user1.setLastName(user.getLastName());
				return user1;
			}
			throw new IllegalArgumentException("User records not updated");
		}
		return user;
	}

}
