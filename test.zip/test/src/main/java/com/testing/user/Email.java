package com.testing.user;


public class Email {

}
