package com.testing.user;

import java.util.Optional;

import com.testing.service.UserService;
import com.testing.service.UserServiceImpl;
import com.testing.test.exception.InvalidNameException;

public class App {

	// public static void main(String[] args) {
	// UserService userService = UserServiceImpl.getInstance();
	// User user = null;
	// try {
	// user = new User("Vi@a12", "sd", "sa", "1234567891", "vijay18@gmail.com");
	//
	// userService.addUser(user);
	// userService.addUser(user);
	// userService.getUsers();
	// userService.deleteUser(user.getId().toString());
	// userService.updateUser(user.getId().toString(), user);
	// if (userService != null) {
	// System.out.println("User added sucessfully");
	// }
	// Optional<User> userResult = userService.getUserById(user.getId().toString());
	//
	// if (userResult.isPresent()) {
	// System.out.println(userResult.get());
	//
	// }
	//
	// } catch (InvalidNameException e) {
	// e.printStackTrace();
	// }
	// }

	public static void main(String[] args) {
		UserService userService = UserServiceImpl.getInstance();
		User user = null;
		String action = "getById";

		try {
			user = new User("Vi@a12", "sd", "sa", "1234567891", "vijay18@gmail.com");

			switch (action) {
				case "add":
					userService.addUser(user);
					System.out.println("User added successfully");
					break;

				case "update":
					userService.updateUser(user.getId().toString(), user);
					System.out.println("User updated successfully");
					break;

				case "delete":
					userService.deleteUser(user.getId().toString());
					System.out.println("User deleted successfully");
					break;

				case "get":
					userService.getUsers(); // Fetch and print all users
					System.out.println("Fetched all users successfully");
					break;

				case "getById":
					userService.addUser(user);
					userService.addUser(user);
					Optional<User> userResult = userService.getUserById(user.getId().toString());
					if (userResult.isPresent()) {
						System.out.println("User found: " + userResult.get());
					} else {
						System.out.println("User not found");
					}
					break;
			}

		} catch (InvalidNameException e) {
			e.printStackTrace();
		}
	}

}
