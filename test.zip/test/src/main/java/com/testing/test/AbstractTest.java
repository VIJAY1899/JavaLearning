package com.testing.test;


public abstract class AbstractTest implements I1, I2, I3 {

	@Override
	public void method5() {
		System.out.println("method5");

	}

	@Override
	public void method6() {
		System.out.println("method6");

	}

	@Override
	public void method7() {
		System.out.println("method7");

	}

	@Override
	public void method2() {
		System.out.println("method2");

	}

	@Override
	public void method3() {
		System.out.println("method3");

	}

	@Override
	public void method4() {
		System.out.println("method4");

	}

	AbstractTest ff = new Concrete();// only call AbstractTest class methods and implements other class method
	Concrete fsf = new Concrete();// only call concrete class method
	I2 i2 = new Concrete();// only call interfcae I2 class method

}
