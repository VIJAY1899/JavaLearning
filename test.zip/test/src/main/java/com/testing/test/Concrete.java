package com.testing.test;


public class Concrete extends AbstractTest {

	@Override
	public void method1() {
		System.out.println("method1");

	}

	@Override
	public void method8() {
		System.out.println("method8");

	}

	@Override
	public void method9() {
		System.out.println("method9");

	}

}
