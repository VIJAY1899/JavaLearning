package com.testing.service;

import java.util.List;
import java.util.Optional;

import com.testing.repo.UserRepository;
import com.testing.repo.UserRepositoryImpl;
import com.testing.test.exception.InvalidNameException;
import com.testing.user.User;


public class UserServiceImpl implements UserService {

	private UserRepository userRepository = UserRepositoryImpl.getInstance();
	private static UserServiceImpl userServiceImpl;

	private UserServiceImpl() {
	}

	public static UserServiceImpl getInstance() {
		if (userServiceImpl == null) {
			userServiceImpl = new UserServiceImpl();
		}
		return userServiceImpl;
	}

	@Override
	public User addUser(User user) {
		return userRepository.addUser(user);
	}

	@Override
	public Optional<User> getUserById(String id) {
		System.out.println("id!!!>>>>>>>" + id);
		return userRepository.getUserById(id);
	}

	@Override
	public Optional<List<User>> getUsers() {
		return userRepository.getUsers();
	}

	@Override
	public void deleteUser(String id) {
		System.out.println("id>>>>>>>>>>>" + id);
		userRepository.deleteUser(id);

	}

	@Override
	public User updateUser(String id, User user) throws InvalidNameException {
		System.out.println("id>>>>" + id);
		System.out.println("user>>>>" + user);
		return userRepository.updateUser(id, user);
	}

}
